package com.Proyecto_JS.ProyectoJS;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProyectoJsApplicationTests {

	@Test
	void contextLoads() {
	}

}
