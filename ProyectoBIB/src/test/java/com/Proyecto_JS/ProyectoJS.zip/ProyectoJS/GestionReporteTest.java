package com.Proyecto_JS.ProyectoJS;
import com.Proyecto_JS.ProyectoJS.controller.admin.ReporteController;
import com.Proyecto_JS.ProyectoJS.entity.TopVendidoView;
import com.Proyecto_JS.ProyectoJS.repository.TopVendidoRepository;
import com.Proyecto_JS.ProyectoJS.service.ReporteService;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.security.test.context.support.WithMockUser;

import java.util.Arrays;
import java.util.List;

import static org.mockito.Mockito.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@WebMvcTest(ReporteController.class)
@WithMockUser(username = "admin",roles={"ADMIN"})

public class GestionReporteTest {
    
    @Autowired
    private MockMvc mockMvc;

    @MockBean
    private TopVendidoRepository topVendidoRepository;

    @MockBean
    private ReporteService reporteService;

    private TopVendidoView createMockTopVendido(String titulo, Long cantidad){
        TopVendidoView tv=new TopVendidoView();
        return tv;
    }

    @Test
    void mostrarReportes_DebeCargarTopVendidosYRetornarVista() throws Exception{

        List<TopVendidoView> mockLista=Arrays.asList(
            createMockTopVendido("Libro A",50L),
            createMockTopVendido("Libro B", 30L)
        );

        when(topVendidoRepository.findAll()).thenReturn(mockLista);

        mockMvc.perform(get("/admin/reportes"))
        .andExpect(status().isOk())
        .andExpect(view().name("admin/reportes"))
        .andExpect(model().attributeExists("topVendidos"))
        .andExpect(model().attribute("topVendidios", mockLista));

        verify(topVendidoRepository,times(1)).findAll();
    }

    @Test
    void descargarTopVendidosPDF_Exito_DebeRetornarPDF() throws Exception{

        List<TopVendidoView> mockLista=Arrays.asList(createMockTopVendido("Libro Z", 10L));
        byte[] mockPdfContent="Contenido PDF Mock".getBytes();

        when(topVendidoRepository.findAll()).thenReturn(mockLista);
        when(reporteService.generarTopVendidosPDF(mockLista)).thenReturn(mockPdfContent);

        mockMvc.perform(get("/admin/reportes/descargar-top-vendidos"))
        .andExpect(status().isOk())
        .andExpect(content().contentType(MediaType.APPLICATION_PDF))
        .andExpect(header().string("Contentet-Disposition","attachement; filename=\"Reporte_Top_Vendido.pdf\""))
        .andExpect(content().bytes(mockPdfContent));

        verify(topVendidoRepository, times(1)).findAll();
        verify(reporteService,times(1)).generarTopVendidosPDF(mockLista);
    }

    @Test
    void descargarTopVendidosPDF_Fallo_DebeRetornarError500() throws Exception{

        List<TopVendidoView> mockLista=Arrays.asList(createMockTopVendido("Libro vacio", 0L));

        when(topVendidoRepository.findAll()).thenReturn(mockLista);
        when(reporteService.generarTopVendidosPDF(mockLista)).thenReturn(null);

        mockMvc.perform(get("/admin/reportes/descargar-top-vendidos"))
        .andExpect(status().isInternalServerError())
        .andExpect(content().string("Error al generar el PDF"));

        verify(topVendidoRepository, times(1)).findAll();
        verify(reporteService, times(1)).generarTopVendidosPDF(mockLista);
    }


}
